package com.ejercicios.spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EjerciciosSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(EjerciciosSpringApplication.class, args);
	}

}
