package ejercicios.clean.code;

public class Main {

    //Ejercicio1
    public static void main(String[] args) {


    }
}
