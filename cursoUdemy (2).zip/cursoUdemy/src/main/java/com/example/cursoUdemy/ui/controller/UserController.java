package com.example.cursoUdemy.ui.controller;


import com.example.cursoUdemy.ui.model.request.UserDetailsRequestModel;
import com.example.cursoUdemy.ui.model.response.UserRest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.awt.*;

@RestController
@RequestMapping("/users")
public class UserController {

    //Búsqueda por número de página y límite de usuarios mostrados
    //Parámetros por defecto con default
    //Parámetros opcionales con required. No funciona correctamente con tipos de dato primitivos
    @GetMapping
    public String getUsers(@RequestParam(value="page", defaultValue="1") int page,
                           @RequestParam(value="limit", defaultValue="50") int limit,
                           @RequestParam(value="sort", defaultValue="desc",required = false) String sort)
    {
        return "get users was called with page = " + page + " and limit " + limit + " and sort = " + sort;
    }

    //Búsqueda por ID
    @GetMapping(path="/{userId}", produces = {MediaType.APPLICATION_XML_VALUE, MediaType.APPLICATION_JSON_VALUE})
    public ResponseEntity<UserRest> getUser(@PathVariable String userId){

        UserRest returnValue = new UserRest();
        returnValue.setEmail("hola@hola.com");
        returnValue.setFirstName("Raúl");
        returnValue.setLastName("Montes");

        return new ResponseEntity<UserRest>(returnValue, HttpStatus.OK);
    }

    @PostMapping(consumes = {MediaType.APPLICATION_XML_VALUE, MediaType.APPLICATION_JSON_VALUE},
            produces = {MediaType.APPLICATION_XML_VALUE, MediaType.APPLICATION_JSON_VALUE})
    public String createUser(@RequestBody UserDetailsRequestModel userDetails){
        return "create user was called";
    }

    @PutMapping
    public String updateUser(){
        return "update user wass called";
    }

    @DeleteMapping
    public String deleteUser(){
        return "delete user was called";
    }
}
