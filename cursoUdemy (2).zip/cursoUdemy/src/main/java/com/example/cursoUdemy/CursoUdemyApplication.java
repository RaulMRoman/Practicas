package com.example.cursoUdemy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CursoUdemyApplication {

	public static void main(String[] args) {
		SpringApplication.run(CursoUdemyApplication.class, args);
	}

}
